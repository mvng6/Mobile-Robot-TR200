"""
Custom protocol buffer messages
"""

# Import any custom protocol buffer messages here
# This directory is reserved for user-defined messages 